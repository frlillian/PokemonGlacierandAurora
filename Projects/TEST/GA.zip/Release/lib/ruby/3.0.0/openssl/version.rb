# frozen_string_literal: true

module OpenSSL
  VERSION = "2.2.0"
end
